//Includes C default
#include <stdio.h>
#include <math.h>
//Includes CPP
#include <iostream>
#include <sstream>
using namespace std;

//Classe vetor
class Vetor;